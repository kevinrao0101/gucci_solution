package portLogistics;

import java.util.ArrayList;
import java.util.Scanner;

public class PortLogistics {

	Container ship;
	Container containerStorage;
	Container train;
	Carne carne1;
	Carne carne2;
	char[][] portLogistics;
	
	public PortLogistics() {
		containerStorage = new Container(5, 0);
		train = new Container(3, 0);
		carne1 = new Carne(null, containerStorage);
		carne2 = new Carne(containerStorage, train);
		portLogistics = new char[7][12];
	}
	
	public static void main(String[] args) {
		PortLogistics pl = new PortLogistics();
		pl.initPortLogistics();
		while(true) {
			ArrayList<String> commandList = pl.readCommands();
			for(String command : commandList) {
				if(command.equals("show"))
					pl.show();
				if(command.equals("receive_ship"))
					pl.receiveShip();;
				if(command.equals("unload"))
					pl.unload();
				if(command.equals("train_send"))
					pl.trainSend();
				if(command.equals("clear"))
					pl.clear();
			}
		}	
	}
	
	public char[][] initPortLogistics() {
		for(int m = 0; m < 7; m++) {
			for(int n = 0; n < 12; n++) {
				portLogistics[m][n] = ' ';
			}
		}
		portLogistics[0][0] = '_';
	    portLogistics[0][1] = '^';
	    portLogistics[0][2] = '_';
	    portLogistics[0][3] = '^';
	    portLogistics[5][9] = 'D';
	    portLogistics[5][11] = 'i';
	    portLogistics[6][0] = ' ';
	    portLogistics[6][1] = 'A';
	    portLogistics[6][2] = '_';
	    portLogistics[6][3] = 'A';
	    portLogistics[6][4] = '-';
	    portLogistics[6][5] = '-';
	    portLogistics[6][6] = '-';
	    portLogistics[6][7] = ':';
	    portLogistics[6][8] = ':';
	    portLogistics[6][9] = '%';
	    portLogistics[6][10] = '%';
	    portLogistics[6][11] = '%';
	    for(int i = 1; i <=5; i++){
	    	portLogistics[i][1] = '|';
	    }
	    for(int i = 1; i <=5; i++){
	    	portLogistics[i][3] = '|';
	    }
	    return portLogistics;
	}
	
	public ArrayList<String> readCommands(){
		Scanner scanner = new Scanner(System.in);
		ArrayList<String> commandList = new ArrayList<>();
		while(true) {
			String command = scanner.nextLine();
			commandList.add(command.toLowerCase());
			if(command.toLowerCase().equals("show"))
				break;
		}
		return commandList;
	}
	
	public void show() {
		initPortLogistics();
		if(ship != null) {
			portLogistics[6][0] = 'V';
			for(int i = 1; i <= ship.load; i++) {
				portLogistics[6 - i][0] = 'X';
			}
		}
		for(int i = 1; i <= containerStorage.load; i++) {
			portLogistics[6 - i][2] = 'X';
		}
		for(int i = 1; i <= train.load; i++) {
			portLogistics[5][3 + i] = 'X';
		}
		int i = portLogistics.length;
		int j = portLogistics[0].length;
		for(int m = 0; m < i; m++) {
			for(int n = 0; n < j; n++) {
				System.out.print(portLogistics[m][n]);
				if(n == j - 1)
					System.out.println("\n");
			}
		}    
	}
	
	public void receiveShip() {
		this.ship = new Container(4, 4);
		this.carne1.setSource(ship);
	}
	
	public void unload() {
		while(ship != null && true) {
			if(train.full() && containerStorage.full())
				break;
			if(train.full() && ship.empty())
				break;
			if(ship.empty() && containerStorage.empty())
				break;
			if(!containerStorage.full() && !ship.empty() ) {
				carne1.move();
			}
			if(!train.full() && !containerStorage.empty()) {
				carne2.move();
			}
		}
	}
	
	public void trainSend() {
		train = new Container(3, 0);
		carne2.setTarget(train);
	}
	
	public void clear() {
		ship = null;
		containerStorage = new Container(5, 0);
		train = new Container(3, 0);
		carne1 = new Carne(ship, containerStorage);
		carne2 = new Carne(containerStorage, train);
		initPortLogistics();
	}

}
