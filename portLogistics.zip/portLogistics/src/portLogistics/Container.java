package portLogistics;

public class Container {

	public int capacity;
	public int load;
	
	public Container(int capacity, int load) {
		this.capacity = capacity;
		this.load = load;
	}
	
	public void unload() {
		capacity--;
	}
	
	public void upload() {
		capacity++;
	}

	public boolean full() {
		return load == capacity;
	}
	
	public boolean empty() {
		return load == 0;
	}
	
	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public int getLoad() {
		return load;
	}

	public void setLoad(int load) {
		this.load = load;
	}
}
