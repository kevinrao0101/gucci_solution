package portLogistics;

public class Carne {
	
	Container source;
	Container target;
	
	public Carne(Container source, Container target) {
		this.source = source;
		this.target = target;
	}
	
	public void move() {
		source.load--;
		target.load++;
	}

	public Container getSource() {
		return source;
	}

	public void setSource(Container source) {
		this.source = source;
	}

	public Container getTarget() {
		return target;
	}

	public void setTarget(Container target) {
		this.target = target;
	}
	
}
